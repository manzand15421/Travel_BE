import { PrismaClient } from "@prisma/client";
import axios from "axios";

const prisma = new PrismaClient();

export class TravelRepository {

  async CallTravelNoReg(NOREG: string = '', ROWSTART: number, ROWEND: number) {
    const result = await prisma.$queryRaw`EXEC dbo.sp_GetTravelNoReg @NOREG = ${NOREG}, @ROWSTART = ${ROWSTART}, @ROWEND = ${ROWEND}`;
    return result; 
  }
  

  async HrLogin(username: string, password: string , mobileno : string) {
    const result = await axios.post('https://hrportal.toyota.co.id/Login/CheckSCMobile', {
      username,
      password,
      mobileno
    });
    return result;
  }

}
